
package com.sun.tools.xjc.generator.annotation.spec;

import javax.xml.bind.annotation.XmlTransient;
import com.sun.codemodel.JAnnotationWriter;

public interface XmlTransientWriter
    extends JAnnotationWriter<XmlTransient>
{


}
